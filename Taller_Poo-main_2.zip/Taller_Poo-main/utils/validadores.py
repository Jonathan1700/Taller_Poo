"""
utils/validadores.py
─────────────────────────────────────────────────────────────────────────────
Decoradores para validar inputs de consola dentro del marco de ejecución
del Taller POO.

La arquitectura:
  - pared_input (en menu_controller) inyecta en builtins._marco_estado un
    dict con la geometría del marco y el dict `estado` que controla la fila.
  - Cuando hay un error, el validador usa ese estado para REDIBUJAR la misma
    fila: borra el contenido erróneo, muestra el error en rojo dentro del
    marco, espera DELAY_ERROR segundos, y restaura el prompt limpio — todo
    en la MISMA fila, sin avanzar estado["fila"].

Uso en ejercicios:
    from utils.validadores import pedir_entero, pedir_flotante, pedir_texto

    edad   = pedir_entero("Ingrese su edad: ", minimo=0, maximo=120)
    precio = pedir_flotante("Precio: ", minimo=0.01)
    nombre = pedir_texto("Nombre: ", min_len=2)

Decorador @validar_input para funciones propias:
    from utils.validadores import validar_input

    @validar_input(lambda v: v.isdigit() and int(v) > 0,
                   "Debe ser un número positivo")
    def mi_funcion():
        return input("Código: ")
─────────────────────────────────────────────────────────────────────────────
"""

import sys
import time
import builtins
import functools
import re

# ── Delay antes de limpiar el mensaje de error y reintentar ───────────────
DELAY_ERROR: float = 0.8

# ── Colores ANSI ──────────────────────────────────────────────────────────
_RESET   = "\033[0m"
_ROJO    = "\033[38;2;255;80;80m"
_NEGRITA = "\033[1m"
_DESC    = "\033[38;2;180;220;255m"   # C_DESC_EJ — mismo color que pared_input


def _strip_ansi(t: str) -> str:
    return re.sub(r'\033\[[0-9;]*[mA-Za-z]', '', t)


def _write(t: str) -> None:
    sys.stdout.write(t)
    sys.stdout.flush()


# ─────────────────────────────────────────────────────────────────────────────
#   NÚCLEO: leer en la MISMA fila, redibujar error, reintentar
# ─────────────────────────────────────────────────────────────────────────────

def _leer_con_reintento(prompt: str, validar_fn, mensaje_error: str) -> str:
    """
    Llama a builtins.input(prompt) y, si la validación falla:
      · Dentro del marco (pared_input activo): usa la geometría guardada en
        builtins._marco_estado para redibujar la MISMA fila con el error en
        rojo, esperar DELAY_ERROR s, limpiar y repetir — sin avanzar de fila.
      · En terminal normal (sin marco): usa \\r para sobreescribir la línea.
    """
    _input = builtins.input

    while True:
        raw = _input(prompt)

        if validar_fn(raw):
            return raw

        # ── ERROR: obtener contexto del marco si existe ────────────────────
        ms = getattr(builtins, "_marco_estado", None)

        if ms is not None:
            # Dentro del marco — redibujar la fila actual con el error
            x_ini   = ms["x_ini"]
            x_fin   = ms["x_fin"]
            inter   = ms["inter"]
            cb      = ms["cb"]
            estado  = ms["estado"]
            V       = ms["V"]
            RESET   = ms["RESET"]

            # La fila que acaba de usar pared_input es (estado["fila"] - 1)
            # porque pared_input ya hizo estado["fila"] += 1 al terminar.
            yf = estado["fila"] - 1

            # 1) Borrar contenido de esa fila y dibujar el error
            _gotoxy(x_ini, yf)
            _write(f"{cb}{V}{RESET}")
            err_txt = _strip_ansi(f"⚠  {mensaje_error}")
            err_vis = err_txt[:inter - 4]
            _gotoxy(x_ini + 2, yf)
            _write(f"{_ROJO}{_NEGRITA}{err_vis}{_RESET}")
            blancos = inter - 2 - len(err_vis)
            if blancos > 0:
                _write(" " * blancos)
            _gotoxy(x_fin, yf)
            _write(f"{cb}{V}{RESET}")
            sys.stdout.flush()

            time.sleep(DELAY_ERROR)

            # 2) Limpiar la fila y retroceder el contador para reusar la fila
            _gotoxy(x_ini, yf)
            _write(f"{cb}{V}{RESET}")
            _gotoxy(x_ini + 1, yf)
            _write(" " * inter)
            _gotoxy(x_fin, yf)
            _write(f"{cb}{V}{RESET}")
            sys.stdout.flush()

            # Devolver el contador de fila para que pared_input reutilice la misma
            estado["fila"] -= 1

        else:
            # Terminal normal — sobreescribir con \r
            visible = len(_strip_ansi(prompt)) + len(raw) + 4
            err_msg = f"⚠  {mensaje_error}"
            _write(f"\r{' ' * (visible + len(err_msg) + 4)}\r"
                   f"{_ROJO}{_NEGRITA}{err_msg}{_RESET}")
            sys.stdout.flush()
            time.sleep(DELAY_ERROR)
            _write(f"\r{' ' * (len(err_msg) + 8)}\r")
            sys.stdout.flush()


def _gotoxy(x, y):
    sys.stdout.write(f"\033[{y};{x}H")


# ─────────────────────────────────────────────────────────────────────────────
#   DECORADOR GENÉRICO  @validar_input
# ─────────────────────────────────────────────────────────────────────────────

def validar_input(condicion, mensaje_error: str = "Dato inválido, intente de nuevo"):
    """
    Decorador para métodos o funciones que llaman a input() internamente.
    Repite hasta que la condición se cumpla, mostrando el error en la MISMA línea.

    Ejemplo de uso con @ sobre un método:
        @validar_input(lambda v: v.strip() != "", "No puede estar vacío")
        def pedir_nombre(self):
            return input("Nombre: ")

    Ejemplo de uso con @ sobre una función libre:
        @validar_input(lambda v: v.isdigit(), "Solo números")
        def pedir_codigo():
            return input("Código: ")
    """
    def decorador(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            while True:
                resultado = func(*args, **kwargs)
                if condicion(resultado):
                    return resultado

                ms = getattr(builtins, "_marco_estado", None)
                if ms is not None:
                    x_ini  = ms["x_ini"]
                    x_fin  = ms["x_fin"]
                    inter  = ms["inter"]
                    cb     = ms["cb"]
                    estado = ms["estado"]
                    V      = ms["V"]
                    RESET  = ms["RESET"]

                    yf = estado["fila"] - 1
                    _gotoxy(x_ini, yf)
                    _write(f"{cb}{V}{RESET}")
                    err_vis = f"⚠  {mensaje_error}"[:inter - 4]
                    _gotoxy(x_ini + 2, yf)
                    _write(f"{_ROJO}{_NEGRITA}{err_vis}{_RESET}")
                    blancos = inter - 2 - len(err_vis)
                    if blancos > 0:
                        _write(" " * blancos)
                    _gotoxy(x_fin, yf)
                    _write(f"{cb}{V}{RESET}")
                    sys.stdout.flush()

                    time.sleep(DELAY_ERROR)

                    _gotoxy(x_ini, yf)
                    _write(f"{cb}{V}{RESET}")
                    _gotoxy(x_ini + 1, yf)
                    _write(" " * inter)
                    _gotoxy(x_fin, yf)
                    _write(f"{cb}{V}{RESET}")
                    sys.stdout.flush()
                    estado["fila"] -= 1
                else:
                    visible = 60
                    err_msg = f"⚠  {mensaje_error}"
                    _write(f"\r{' ' * (visible + len(err_msg))}\r"
                           f"{_ROJO}{_NEGRITA}{err_msg}{_RESET}")
                    sys.stdout.flush()
                    time.sleep(DELAY_ERROR)
                    _write(f"\r{' ' * (len(err_msg) + 8)}\r")
                    sys.stdout.flush()
        return wrapper
    return decorador


# ─────────────────────────────────────────────────────────────────────────────
#   FUNCIONES DE CONVENIENCIA
# ─────────────────────────────────────────────────────────────────────────────

def pedir_entero(
    prompt: str,
    minimo: int | None = None,
    maximo: int | None = None,
    mensaje_error: str | None = None,
) -> int:
    """Pide un entero válido. Reintenta en la MISMA línea si hay error."""
    def _v(raw):
        try:
            n = int(raw)
        except ValueError:
            return False
        if minimo is not None and n < minimo: return False
        if maximo is not None and n > maximo: return False
        return True

    if mensaje_error is None:
        p = ["Debe ser un número entero"]
        if minimo is not None and maximo is not None: p.append(f"entre {minimo} y {maximo}")
        elif minimo is not None: p.append(f"≥ {minimo}")
        elif maximo is not None: p.append(f"≤ {maximo}")
        mensaje_error = " ".join(p)

    return int(_leer_con_reintento(prompt, _v, mensaje_error))


def pedir_flotante(
    prompt: str,
    minimo: float | None = None,
    maximo: float | None = None,
    mensaje_error: str | None = None,
) -> float:
    """Pide un decimal válido. Reintenta en la MISMA línea si hay error."""
    def _v(raw):
        try:
            n = float(raw.replace(",", "."))
        except ValueError:
            return False
        if minimo is not None and n < minimo: return False
        if maximo is not None and n > maximo: return False
        return True

    if mensaje_error is None:
        p = ["Debe ser un número decimal"]
        if minimo is not None and maximo is not None: p.append(f"entre {minimo} y {maximo}")
        elif minimo is not None: p.append(f"≥ {minimo}")
        elif maximo is not None: p.append(f"≤ {maximo}")
        mensaje_error = " ".join(p)

    return float(_leer_con_reintento(prompt, _v, mensaje_error).replace(",", "."))


def pedir_texto(
    prompt: str,
    min_len: int = 1,
    max_len: int | None = None,
    solo_letras: bool = False,
    mensaje_error: str | None = None,
) -> str:
    """Pide texto válido. Reintenta en la MISMA línea si hay error."""
    def _v(raw):
        s = raw.strip()
        if len(s) < min_len: return False
        if max_len is not None and len(s) > max_len: return False
        if solo_letras and not all(c.isalpha() or c.isspace() for c in s): return False
        return True

    if mensaje_error is None:
        p = []
        if min_len > 1: p.append(f"mínimo {min_len} caracteres")
        if max_len is not None: p.append(f"máximo {max_len} caracteres")
        if solo_letras: p.append("solo letras y espacios")
        mensaje_error = ("Texto inválido: " + ", ".join(p)) if p else "El campo no puede estar vacío"

    return _leer_con_reintento(prompt, _v, mensaje_error).strip()


def pedir_opcion(
    prompt: str,
    opciones: list | tuple | set,
    ignorar_mayusculas: bool = True,
    mensaje_error: str | None = None,
) -> str:
    """Pide una opción de una lista válida. Reintenta en la MISMA línea."""
    ops = [str(o) for o in opciones]

    def _v(raw):
        r = raw.strip().lower() if ignorar_mayusculas else raw.strip()
        return r in ([o.lower() for o in ops] if ignorar_mayusculas else ops)

    if mensaje_error is None:
        mensaje_error = "Opción inválida. Permitidos: " + ", ".join(f"'{o}'" for o in ops)

    raw = _leer_con_reintento(prompt, _v, mensaje_error).strip()
    return raw.lower() if ignorar_mayusculas else raw


def pedir_si_no(prompt: str, mensaje_error: str = "Responde 's' para Sí o 'n' para No") -> bool:
    """Pide s/n. Devuelve True para sí, False para no."""
    resp = pedir_opcion(prompt, ["s", "n", "si", "sí", "no"], mensaje_error=mensaje_error)
    return resp in ("s", "si", "sí")
