from utils.validadores import validar_input

class Login:
    def __init__(self):
        self.usuarios = {}

    @validar_input(lambda v: len(v.strip()) >= 3,
                   "El usuario debe tener al menos 3 caracteres")
    def _pedir_usuario(self):
        return input("Ingrese su nombre de usuario: ")

    @validar_input(lambda v: v.strip().isdigit() and len(v.strip()) >= 4,
                   "La contraseña debe ser numérica y tener al menos 4 dígitos")
    def _pedir_contrasena(self):
        return input("Ingrese su contraseña (solo números): ")

    @validar_input(lambda v: len(v.strip()) >= 1,
                   "El campo no puede estar vacío")
    def _pedir_usuario_login(self):
        return input("Ingrese su nombre de usuario: ")

    @validar_input(lambda v: len(v.strip()) >= 1,
                   "El campo no puede estar vacío")
    def _pedir_contrasena_login(self):
        return input("Ingrese su contraseña: ")

    def registrar(self):
        usuario    = self._pedir_usuario()
        contraseña = int(self._pedir_contrasena())
        self.usuarios[usuario] = contraseña
        print(f"El usuario {usuario} ha sido registrado.")

    def inicio(self):
        if not self.usuarios:
            print("No hay usuarios registrados.")
            return
        usuario    = self._pedir_usuario_login()
        contraseña = self._pedir_contrasena_login()
        try: c = int(contraseña)
        except: c = contraseña
        if usuario in self.usuarios and self.usuarios[usuario] == c:
            print(f"¡Bienvenido, {usuario}!")
        else:
            print("Nombre de usuario o contraseña incorrectos.")

a = Login()
a.registrar()
a.inicio()
