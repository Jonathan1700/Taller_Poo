from utils.validadores import validar_input

def _es_float_no_neg(v):
    try: return float(v.replace(",",".")) >= 0
    except: return False

class Banco:
    def __init__(self):
        self.cuentas = {}
        self.usuario_actual = None

    @validar_input(lambda v: len(v.strip()) >= 3,
                   "El nombre debe tener al menos 3 caracteres")
    def _pedir_usuario(self):
        return input("Ingrese el nombre de Usuario: ")

    @validar_input(lambda v: len(v.strip()) >= 4,
                   "La contraseña debe tener al menos 4 caracteres")
    def _pedir_contrasena(self):
        return input("Ingrese su contraseña: ")

    @validar_input(lambda v: v.strip().isdigit() and len(v.strip()) == 4,
                   "El PIN debe ser exactamente 4 dígitos numéricos")
    def _pedir_pin(self):
        return input("Ingrese su PIN (4 dígitos): ")

    @validar_input(lambda v: len(v.strip()) >= 1,
                   "No puede estar vacío")
    def _pedir_usuario_login(self):
        return input("Ingrese su nombre de usuario: ")

    @validar_input(lambda v: len(v.strip()) == 4 and v.strip().isdigit(),
                   "El PIN debe ser exactamente 4 dígitos")
    def _pedir_pin_login(self):
        return input("Ingrese su PIN: ")

    @validar_input(lambda v: _es_float_no_neg(v),
                   "Debe ser un número mayor o igual a 0")
    def _pedir_saldo(self):
        return input("Ingrese su saldo: ")

    def registrar_cuenta(self):
        nombre = self._pedir_usuario()
        contra = self._pedir_contrasena()
        pin    = self._pedir_pin()
        self.cuentas[nombre] = {"contraseña": contra, "pin": pin}
        print(f"Cuenta creada para: {nombre}")

    def iniciar_sesion(self):
        nombre = self._pedir_usuario_login()
        pin    = self._pedir_pin_login()
        if nombre in self.cuentas and self.cuentas[nombre]["pin"] == pin:
            self.usuario_actual = nombre
            print(f"Bienvenido, {nombre}")
        else:
            print("Usuario o PIN incorrecto")

    def verificar_saldo(self):
        if self.usuario_actual is None:
            print("No hay sesión activa.")
            return
        saldo = float(self._pedir_saldo())
        print(f"Su saldo es de: {saldo:.2f}")

    def tipo_cuenta(self):
        if self.usuario_actual is None:
            print("Inicia sesión primero.")
            return
        saldo = float(self._pedir_saldo())
        if saldo >= 10000:   print("Cuenta Premium")
        elif saldo >= 5000:  print("Cuenta Estándar")
        elif saldo >= 1000:  print("Cuenta Básica")
        else:                print("Saldo insuficiente para abrir cuenta")

banco = Banco()
banco.registrar_cuenta()
banco.iniciar_sesion()
banco.verificar_saldo()
banco.tipo_cuenta()
