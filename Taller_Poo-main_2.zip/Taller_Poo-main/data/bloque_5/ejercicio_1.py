from utils.validadores import validar_input

class Condicionales:

    @validar_input(lambda v: v.strip().lstrip("-").isdigit(),
                   "Debe ser un número entero")
    def _pedir_numero(self):
        return input("Ingrese un número: ")

    @validar_input(lambda v: v.strip().isdigit() and 0 <= int(v) <= 100,
                   "Debe ser una calificación entre 0 y 100")
    def _pedir_calificacion(self):
        return input("Ingrese la calificación: ")

    def pedir_numero(self):
        num = int(self._pedir_numero())
        print("El número es par." if num % 2 == 0 else "El número es impar.")

    def calificaciones(self):
        c = int(self._pedir_calificacion())
        if c >= 90:   print("A")
        elif c >= 80: print("B")
        elif c >= 70: print("C")
        else:         print("D")

condicionales = Condicionales()
condicionales.pedir_numero()
condicionales.calificaciones()
