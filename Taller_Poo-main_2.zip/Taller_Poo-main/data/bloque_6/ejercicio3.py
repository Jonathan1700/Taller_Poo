from utils.validadores import validar_input

class Salon:
    def __init__(self):
        self.estudiantes = []

    @validar_input(lambda v: len(v.strip()) >= 1,
                   "El nombre no puede estar vacío")
    def _pedir_estudiante(self):
        return input("Ingrese estudiante (o 'listo' para terminar): ")

    @validar_input(lambda v: len(v.strip()) >= 1,
                   "El nombre no puede estar vacío")
    def _pedir_busqueda(self):
        return input("Ingrese el nombre que desea buscar: ")

    def agregar_estudiantes(self):
        while True:
            nombre = self._pedir_estudiante()
            if nombre.strip().lower() == "listo":
                break
            self.estudiantes.append(nombre.strip())

    def mostrar_lista(self):
        for indice, est in enumerate(self.estudiantes, 1):
            print(indice, est)

    def buscar_estudiantes(self):
        nombre = self._pedir_busqueda()
        for est in self.estudiantes:
            if est == nombre:
                print("Estudiante encontrado")
                break
        else:
            print("Estudiante no encontrado")

    def mejores_notas(self):
        notas = [5, 8, 3, 9, 6, 10, 4, 7]
        print(f"Las mejores notas son: {[x for x in notas if x > 6]}")

salon = Salon()
salon.agregar_estudiantes()
salon.mostrar_lista()
salon.buscar_estudiantes()
salon.mejores_notas()
