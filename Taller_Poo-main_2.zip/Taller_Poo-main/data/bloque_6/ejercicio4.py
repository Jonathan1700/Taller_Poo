from utils.validadores import validar_input

class Inventario:
    def __init__(self):
        self.producto = []

    @validar_input(lambda v: len(v.strip()) >= 1,
                   "El nombre no puede estar vacío")
    def _pedir_producto(self):
        return input("Ingrese el nombre del producto (o 'listo' para terminar): ")

    @validar_input(lambda v: len(v.strip()) >= 1,
                   "El nombre no puede estar vacío")
    def _pedir_busqueda(self):
        return input("Ingrese el producto a buscar: ")

    def agregar_productos(self):
        while True:
            prod = self._pedir_producto()
            if prod.strip().lower() == "listo":
                break
            self.producto.append(prod.strip())

    def mostrar_productos(self):
        for indice, prd in enumerate(self.producto, 1):
            print(indice, prd)

    def buscar_producto(self):
        nombre = self._pedir_busqueda()
        for prd in self.producto:
            if prd == nombre:
                print("Producto encontrado")
                break
        else:
            print("Producto no encontrado")

    def productos_caros(self):
        caros = [150, 800, 50, 1200, 300, 900, 25, 600]
        print([x for x in caros if x > 500])

inventario = Inventario()
inventario.agregar_productos()
inventario.mostrar_productos()
inventario.buscar_producto()
inventario.productos_caros()
