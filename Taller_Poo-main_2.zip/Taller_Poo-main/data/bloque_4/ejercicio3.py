from utils.validadores import validar_input

def _es_float_pos(v):
    try: return float(v.replace(",",".")) > 0
    except: return False

def _es_int_pos(v):
    try: return int(v) > 0
    except: return False

class Restaurante:
    def __init__(self):
        self.platos = []

    @validar_input(lambda v: v.strip() != "" and len(v.strip()) >= 2,
                   "El nombre debe tener al menos 2 caracteres")
    def _pedir_nombre(self):
        return input("Ingrese el nombre del cliente: ")

    @validar_input(lambda v: v.strip() != "" and len(v.strip()) >= 2,
                   "El plato debe tener al menos 2 caracteres")
    def _pedir_plato(self):
        return input("Ingrese el plato deseado: ")

    @validar_input(lambda v: _es_float_pos(v),
                   "Debe ser un número decimal mayor a 0")
    def _pedir_precio(self):
        return input("Ingrese el precio del plato: ")

    @validar_input(lambda v: _es_int_pos(v),
                   "Debe ser un número entero positivo")
    def _pedir_cantidad(self):
        return input("Ingrese la cantidad de platos: ")

    @validar_input(lambda v: v.strip().lstrip("-").isdigit() and int(v) >= 1,
                   "Debe ser un número de mesa válido (≥ 1)")
    def _pedir_mesa(self):
        return input("Ingrese un número de mesa: ")

    def registrar_cliente(self):
        nombre = self._pedir_nombre()
        plato  = self._pedir_plato()
        self.platos.append((nombre, plato))

    def calcular_cuenta(self):
        precio   = float(self._pedir_precio())
        cantidad = int(self._pedir_cantidad())
        subtotal = precio * cantidad
        iva      = subtotal * 0.12
        print(f"Subtotal: {subtotal:.2f}")
        print(f"IVA:      {iva:.2f}")
        print(f"Total:    {subtotal + iva:.2f}")

    def sin_castear(self):
        numero = self._pedir_mesa()
        print(numero + "-vip")

restaurante = Restaurante()
restaurante.registrar_cliente()
restaurante.calcular_cuenta()
restaurante.sin_castear()
