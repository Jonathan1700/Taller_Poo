from utils.validadores import validar_input, pedir_flotante

class Compra:
    def __init__(self):
        self.productos = []

    @validar_input(lambda v: v.strip() != "" and len(v.strip()) >= 2,
                   "El nombre debe tener al menos 2 caracteres")
    def _pedir_nombre(self):
        return input("Ingrese el nombre del producto: ")

    @validar_input(lambda v: _es_float_pos(v),
                   "Debe ser un número mayor a 0")
    def _pedir_precio(self):
        return input("Ingrese el precio del producto: ")

    @validar_input(lambda v: _es_float_pos(v),
                   "Debe ser un número mayor a 0")
    def _pedir_precio_original(self):
        return input("Ingrese el precio original del producto: ")

    @validar_input(lambda v: v.strip() != "",
                   "No puede estar vacío")
    def _pedir_num_str(self):
        return input("Ingrese un número: ")

    def registrar_producto(self):
        nombre = self._pedir_nombre()
        precio = float(self._pedir_precio())
        self.productos.append((nombre, precio))
        print(f"Producto registrado: {nombre} | Precio: ${precio:.2f}")

    def calcular_descuento(self):
        if not self.productos:
            print("No hay productos registrados.")
            return
        precio_original = float(self._pedir_precio_original())
        descuento = precio_original * 0.2
        print(f"Descuento: ${descuento:.2f}")
        print(f"Precio final: ${precio_original - descuento:.2f}")

    def concatenar_sin_castear(self):
        num = self._pedir_num_str()
        print(num + "00")

def _es_float_pos(v):
    try: return float(v.replace(",", ".")) > 0
    except: return False

compra = Compra()
compra.registrar_producto()
compra.calcular_descuento()
compra.concatenar_sin_castear()
