from utils.validadores import validar_input, pedir_entero

class Entrada_Salida:

    @validar_input(lambda v: v.strip() != "" and all(c.isalpha() or c.isspace() for c in v.strip()),
                   "Solo letras y espacios, no puede estar vacío")
    def _pedir_nombre(self):
        return input("Ingrese su nombre: ")

    @validar_input(lambda v: v.strip().lstrip("-").isdigit() and 0 <= int(v) <= 120,
                   "Debe ser un número entero entre 0 y 120")
    def _pedir_edad(self):
        return input("Ingrese su edad: ")

    @validar_input(lambda v: v.strip().lstrip("-").isdigit(),
                   "Debe ser un número entero")
    def _pedir_numero(self):
        return input("Ingrese un número: ")

    def nombre_edad(self):
        nombre = self._pedir_nombre()
        edad   = int(self._pedir_edad())
        print(f"Su nombre es {nombre} y tiene {edad} años.")

    def promedios(self):
        num1 = int(pedir_entero("Ingrese el primer número: "))
        num2 = int(pedir_entero("Ingrese el segundo número: "))
        print(f"El promedio es: {(num1 + num2) / 2}")

    def sin_conversion(self):
        numero = self._pedir_numero()
        print(numero + "5")
        print("Explicación: no se sumaron, se concatenaron como texto.")

resultados = Entrada_Salida()
resultados.nombre_edad()
resultados.promedios()
resultados.sin_conversion()
